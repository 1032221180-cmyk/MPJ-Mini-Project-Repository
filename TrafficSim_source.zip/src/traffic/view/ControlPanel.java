package traffic.view;

import traffic.controller.TrafficScheduler;
import traffic.strategy.GreenTimeStrategy;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class ControlPanel extends JPanel {

    private final TrafficScheduler scheduler;
    private final JLabel statusLabel;
    private final JLabel[] densityLabels = new JLabel[4];

    public ControlPanel(TrafficScheduler s) {
        this.scheduler = s;
        setBackground(new Color(16, 18, 26));
        setPreferredSize(new Dimension(200, SimulationPanel.H));
        setLayout(new BorderLayout(0, 10));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(new Color(16, 18, 26));

        content.add(sectionHeader("◼ TRAFFIC SIM"));
        content.add(Box.createVerticalStrut(12));

        // Strategy toggle
        content.add(sectionHeader("ALGORITHM"));
        JPanel stratPanel = new JPanel(new GridLayout(2, 1, 4, 4));
        stratPanel.setBackground(new Color(16, 18, 26));
        JButton btnDensity = styledButton("Density-Weighted");
        JButton btnRR      = styledButton("Round Robin");
        btnDensity.setBackground(new Color(40, 140, 80));
        btnDensity.addActionListener(e -> {
            scheduler.setStrategy(new GreenTimeStrategy.DensityWeighted());
            btnDensity.setBackground(new Color(40, 140, 80));
            btnRR.setBackground(new Color(40, 44, 60));
        });
        btnRR.addActionListener(e -> {
            scheduler.setStrategy(new GreenTimeStrategy.RoundRobin(40));
            btnRR.setBackground(new Color(40, 140, 80));
            btnDensity.setBackground(new Color(40, 44, 60));
        });
        stratPanel.add(btnDensity);
        stratPanel.add(btnRR);
        content.add(stratPanel);
        content.add(Box.createVerticalStrut(14));

        // Spawn cars per lane
        content.add(sectionHeader("SPAWN VEHICLE"));
        String[] laneNames = {"North", "South", "East", "West"};
        for (int i = 0; i < 4; i++) {
            final int li = i;
            JButton btn = styledButton("+ " + laneNames[i]);
            btn.addActionListener(e -> scheduler.spawnCarInLane(li));
            content.add(btn);
            content.add(Box.createVerticalStrut(4));
        }
        content.add(Box.createVerticalStrut(10));

        // Ambulance spawners
        content.add(sectionHeader("EMERGENCY"));
        for (int i = 0; i < 4; i++) {
            final int li = i;
            JButton btn = styledButton("🚨 AMB → " + laneNames[i]);
            btn.setBackground(new Color(160, 30, 30));
            btn.setForeground(Color.WHITE);
            btn.addActionListener(e -> scheduler.spawnAmbulance(li));
            content.add(btn);
            content.add(Box.createVerticalStrut(4));
        }
        content.add(Box.createVerticalStrut(14));

        // Status
        content.add(sectionHeader("DENSITY STATUS"));
        JPanel densPanel = new JPanel(new GridLayout(4, 1, 2, 2));
        densPanel.setBackground(new Color(16, 18, 26));
        for (int i = 0; i < 4; i++) {
            densityLabels[i] = new JLabel(laneNames[i] + ": 0");
            densityLabels[i].setForeground(new Color(120, 200, 140));
            densityLabels[i].setFont(new Font("Monospaced", Font.PLAIN, 11));
            densPanel.add(densityLabels[i]);
        }
        content.add(densPanel);
        content.add(Box.createVerticalStrut(10));

        statusLabel = new JLabel("Running");
        statusLabel.setForeground(new Color(40, 200, 100));
        statusLabel.setFont(new Font("Monospaced", Font.BOLD, 11));
        content.add(statusLabel);

        add(content, BorderLayout.NORTH);

        // Tick update for labels
        new Timer(200, e -> updateStatus()).start();
    }

    private void updateStatus() {
        var lanes  = scheduler.getLanes();
        var lights = scheduler.getLights();
        String[] laneNames = {"N", "S", "E", "W"};
        for (int i = 0; i < 4; i++) {
            int d = lanes[i].getDensity();
            densityLabels[i].setText(laneNames[i] + ": " + d + " veh  " + lights[i].getState().name().charAt(0));
            densityLabels[i].setForeground(
                d >= 6 ? new Color(220, 80, 80) :
                d >= 3 ? new Color(255, 180, 40) :
                         new Color(40, 200, 100)
            );
        }
        statusLabel.setText(scheduler.isEmergencyActive() ? "⚠ EMERGENCY" : "Running");
        statusLabel.setForeground(scheduler.isEmergencyActive()
            ? new Color(255, 60, 60) : new Color(40, 200, 100));
    }

    private JLabel sectionHeader(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(new Color(80, 140, 200));
        l.setFont(new Font("Monospaced", Font.BOLD, 10));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private JButton styledButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("Monospaced", Font.PLAIN, 11));
        b.setBackground(new Color(40, 44, 60));
        b.setForeground(new Color(180, 200, 230));
        b.setFocusPainted(false);
        b.setBorder(new CompoundBorder(
            new LineBorder(new Color(60, 66, 90), 1),
            new EmptyBorder(4, 8, 4, 8)
        ));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        return b;
    }
}
