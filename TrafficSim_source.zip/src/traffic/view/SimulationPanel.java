package traffic.view;

import traffic.controller.TrafficScheduler;
import traffic.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.List;

public class SimulationPanel extends JPanel {

    public static final int W = 700;
    public static final int H = 700;

    private static final int ROAD_W     = 80;
    private static final int CX         = W / 2;
    private static final int CY         = H / 2;
    private static final int LIGHT_R    = 12;

    private final TrafficScheduler scheduler;

    // Light positions [laneIdx] → {x, y}
    private static final int[][] LIGHT_POS = {
        {CX + ROAD_W/2 + 18, CY - ROAD_W/2 - 18},  // North light
        {CX - ROAD_W/2 - 18, CY + ROAD_W/2 + 18},  // South light
        {CX + ROAD_W/2 + 18, CY + ROAD_W/2 + 18},  // East light
        {CX - ROAD_W/2 - 18, CY - ROAD_W/2 - 18},  // West light
    };

    public SimulationPanel(TrafficScheduler s) {
        this.scheduler = s;
        setPreferredSize(new Dimension(W, H));
        setBackground(new Color(20, 22, 30));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawRoads(g2);
        drawIntersection(g2);
        drawVehicles(g2);
        drawTrafficLights(g2);
        drawDensityBars(g2);
        drawEventLog(g2);
        drawEmergencyOverlay(g2);
    }

    private void drawRoads(Graphics2D g) {
        g.setColor(new Color(40, 44, 55));
        // Vertical road
        g.fillRect(CX - ROAD_W/2, 0, ROAD_W, H);
        // Horizontal road
        g.fillRect(0, CY - ROAD_W/2, W, ROAD_W);

        // Lane dividers (dashed center lines)
        g.setColor(new Color(80, 86, 100));
        float[] dash = {12f, 10f};
        g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, dash, 0f));
        g.drawLine(CX, 0, CX, CY - ROAD_W/2);
        g.drawLine(CX, CY + ROAD_W/2, CX, H);
        g.drawLine(0, CY, CX - ROAD_W/2, CY);
        g.drawLine(CX + ROAD_W/2, CY, W, CY);
        g.setStroke(new BasicStroke(1f));

        // Road edges
        g.setColor(new Color(60, 66, 80));
        g.setStroke(new BasicStroke(2f));
        g.drawRect(CX - ROAD_W/2, 0, ROAD_W, H);
        g.drawRect(0, CY - ROAD_W/2, W, ROAD_W);
        g.setStroke(new BasicStroke(1f));
    }

    private void drawIntersection(Graphics2D g) {
        g.setColor(new Color(50, 54, 68));
        g.fillRect(CX - ROAD_W/2, CY - ROAD_W/2, ROAD_W, ROAD_W);
        // Zebra crossing hints
        g.setColor(new Color(60, 65, 80));
        for (int i = 0; i < 4; i++) {
            g.fillRect(CX - ROAD_W/2 + i * 8, CY - ROAD_W/2 - 10, 5, 10);
            g.fillRect(CX - ROAD_W/2 + i * 8, CY + ROAD_W/2,      5, 10);
        }
    }

    private void drawTrafficLights(Graphics2D g) {
        TrafficLight[] lights = scheduler.getLights();
        String[] labels = {"N", "S", "E", "W"};
        for (int i = 0; i < TrafficScheduler.LANES; i++) {
            int lx = LIGHT_POS[i][0];
            int ly = LIGHT_POS[i][1];
            LightState state = lights[i].getState();

            // Housing
            g.setColor(new Color(25, 28, 36));
            g.fillRoundRect(lx - LIGHT_R - 4, ly - LIGHT_R - 4,
                            (LIGHT_R + 4) * 2, (LIGHT_R + 4) * 2, 6, 6);
            g.setColor(new Color(60, 66, 80));
            g.drawRoundRect(lx - LIGHT_R - 4, ly - LIGHT_R - 4,
                            (LIGHT_R + 4) * 2, (LIGHT_R + 4) * 2, 6, 6);

            // Light glow
            Color base = stateColor(state);
            Color glow = base.brighter();
            RadialGradientPaint rgp = new RadialGradientPaint(
                lx, ly, LIGHT_R,
                new float[]{0f, 1f},
                new Color[]{glow, base}
            );
            g.setPaint(rgp);
            g.fillOval(lx - LIGHT_R, ly - LIGHT_R, LIGHT_R * 2, LIGHT_R * 2);
            g.setPaint(null);

            // Label
            g.setColor(new Color(180, 190, 210));
            g.setFont(new Font("Monospaced", Font.BOLD, 10));
            g.drawString(labels[i], lx - 3, ly + LIGHT_R + 14);

            // Timer bar
            if (state == LightState.GREEN) {
                int remaining = lights[i].getGreenTimeRemaining();
                // We don't know max easily, estimate 80
                int barW = Math.min(40, remaining / 2);
                g.setColor(new Color(40, 200, 120, 160));
                g.fillRect(lx - 20, ly + LIGHT_R + 16, barW, 4);
                g.setColor(new Color(60, 66, 80));
                g.drawRect(lx - 20, ly + LIGHT_R + 16, 40, 4);
            }
        }
    }

    private Color stateColor(LightState s) {
        return switch (s) {
            case GREEN  -> new Color(40, 220, 100);
            case YELLOW -> new Color(255, 200, 0);
            case RED    -> new Color(220, 50, 60);
        };
    }

    private void drawVehicles(Graphics2D g) {
        Lane[] lanes = scheduler.getLanes();
        for (Lane lane : lanes) {
            for (Vehicle v : lane.getVehicles()) {
                v.draw(g);
                if (!v.isMoving()) {
                    // Waiting indicator
                    g.setColor(new Color(255, 200, 0, 120));
                    g.fillOval((int)v.getX() - 3, (int)v.getY() - 16, 6, 6);
                }
            }
        }
    }

    private void drawDensityBars(Graphics2D g) {
        Lane[] lanes = scheduler.getLanes();
        int panelX = 10;
        int panelY = 10;
        int bw = 110;
        int bh = 14;
        int pad = 4;

        g.setColor(new Color(20, 22, 30, 200));
        g.fillRoundRect(panelX - 4, panelY - 4, bw + 8, (bh + pad) * 4 + 30, 8, 8);
        g.setColor(new Color(60, 66, 80));
        g.drawRoundRect(panelX - 4, panelY - 4, bw + 8, (bh + pad) * 4 + 30, 8, 8);

        g.setColor(new Color(150, 160, 185));
        g.setFont(new Font("Monospaced", Font.BOLD, 10));
        g.drawString("LANE DENSITY", panelX, panelY + 10);

        String[] names = {"N", "S", "E", "W"};
        for (int i = 0; i < 4; i++) {
            int density = lanes[i].getDensity();
            int y = panelY + 20 + i * (bh + pad);

            g.setColor(new Color(80, 88, 108));
            g.fillRoundRect(panelX, y, bw, bh, 4, 4);

            // Fill
            Color fill = density >= 6 ? new Color(220, 80, 80)
                       : density >= 3 ? new Color(255, 160, 0)
                       : new Color(40, 200, 100);
            int fw = (int)((density / 8.0) * bw);
            if (fw > 0) {
                g.setColor(fill);
                g.fillRoundRect(panelX, y, fw, bh, 4, 4);
            }

            g.setColor(new Color(150, 160, 185));
            g.setFont(new Font("Monospaced", Font.PLAIN, 9));
            g.drawString(names[i] + ": " + density + " veh", panelX + 4, y + bh - 3);
        }
    }

    private void drawEventLog(Graphics2D g) {
        List<String> log = scheduler.getLog();
        int panelX = W - 220;
        int panelY = 10;
        int panelH = Math.min(log.size(), 10) * 13 + 24;

        g.setColor(new Color(20, 22, 30, 200));
        g.fillRoundRect(panelX - 4, panelY - 4, 218, panelH, 8, 8);
        g.setColor(new Color(60, 66, 80));
        g.drawRoundRect(panelX - 4, panelY - 4, 218, panelH, 8, 8);

        g.setColor(new Color(150, 160, 185));
        g.setFont(new Font("Monospaced", Font.BOLD, 10));
        g.drawString("EVENT LOG", panelX, panelY + 10);

        g.setFont(new Font("Monospaced", Font.PLAIN, 9));
        for (int i = 0; i < Math.min(log.size(), 10); i++) {
            float alpha = 1f - (i * 0.08f);
            g.setColor(new Color(140, 180, 220, (int)(alpha * 200)));
            g.drawString(log.get(i), panelX, panelY + 22 + i * 13);
        }
    }

    private void drawEmergencyOverlay(Graphics2D g) {
        if (!scheduler.isEmergencyActive()) return;
        long t = System.currentTimeMillis();
        int alpha = (int)(80 + 60 * Math.sin(t * 0.008));
        g.setColor(new Color(220, 50, 50, alpha));
        g.setStroke(new BasicStroke(5f));
        g.drawRect(3, 3, W - 6, H - 6);
        g.setStroke(new BasicStroke(1f));

        g.setFont(new Font("Monospaced", Font.BOLD, 16));
        g.setColor(new Color(255, 80, 80, 220));
        g.drawString("⚠ EMERGENCY OVERRIDE ACTIVE", W/2 - 145, H - 18);
    }
}
