package traffic.strategy;

import traffic.model.Lane;

/** Strategy: compute green-light duration (in ticks) for a given lane. */
public interface GreenTimeStrategy {
    int computeGreenTicks(Lane lane);

    /** Density-weighted: more cars → more green time. Range [20, 80] ticks. */
    class DensityWeighted implements GreenTimeStrategy {
        private static final int BASE    = 20;
        private static final int MAX     = 80;
        private static final int PER_CAR = 8;

        @Override
        public int computeGreenTicks(Lane lane) {
            return Math.min(MAX, BASE + lane.getDensity() * PER_CAR);
        }
    }

    /** Fixed: everyone gets the same slice. Boring but fair. */
    class RoundRobin implements GreenTimeStrategy {
        private final int ticks;
        public RoundRobin(int ticks) { this.ticks = ticks; }

        @Override
        public int computeGreenTicks(Lane lane) { return ticks; }
    }
}
