package traffic.observer;

import traffic.model.Lane;

/** Observer interface — fired whenever a lane's vehicle count changes. */
public interface LaneObserver {
    void onDensityChanged(Lane lane);
}
