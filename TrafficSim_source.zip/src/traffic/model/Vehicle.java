package traffic.model;

import java.awt.*;

public class Vehicle {
    public enum Type { CAR, AMBULANCE }

    private final Type type;
    private double x, y;
    private final double speed;
    private final Color color;
    private boolean moving;
    private final int laneIndex;
    private double targetX, targetY;

    public Vehicle(Type type, double x, double y, double speed, int laneIndex) {
        this.type       = type;
        this.x          = x;
        this.y          = y;
        this.speed      = speed;
        this.laneIndex  = laneIndex;
        this.moving     = true;
        this.targetX    = x;
        this.targetY    = y;
        this.color      = (type == Type.AMBULANCE) ? new Color(255, 50, 50) : randomCarColor();
    }

    private Color randomCarColor() {
        Color[] palette = {
            new Color(41, 182, 246),
            new Color(102, 187, 106),
            new Color(255, 202, 40),
            new Color(171, 71, 188),
            new Color(255, 112, 67),
            new Color(38, 198, 218)
        };
        return palette[(int)(Math.random() * palette.length)];
    }

    public void setTarget(double tx, double ty) {
        this.targetX = tx;
        this.targetY = ty;
    }

    public void update() {
        if (!moving) return;
        double dx = targetX - x;
        double dy = targetY - y;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < speed) {
            x = targetX;
            y = targetY;
        } else {
            x += (dx / dist) * speed;
            y += (dy / dist) * speed;
        }
    }

    public boolean isAmbulance()  { return type == Type.AMBULANCE; }
    public double getX()          { return x; }
    public double getY()          { return y; }
    public int getLaneIndex()     { return laneIndex; }
    public Color getColor()       { return color; }
    public boolean isMoving()     { return moving; }
    public void setMoving(boolean m) { this.moving = m; }
    public Type getType()         { return type; }

    public void draw(Graphics2D g) {
        int w = isAmbulance() ? 22 : 16;
        int h = isAmbulance() ? 12 : 10;
        g.setColor(color);
        g.fillRoundRect((int)x - w/2, (int)y - h/2, w, h, 4, 4);
        if (isAmbulance()) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Monospaced", Font.BOLD, 7));
            g.drawString("AMB", (int)x - 9, (int)y + 3);
        }
        g.setColor(color.darker());
        g.drawRoundRect((int)x - w/2, (int)y - h/2, w, h, 4, 4);
    }
}
