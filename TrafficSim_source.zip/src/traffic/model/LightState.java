package traffic.model;

public enum LightState {
    RED, GREEN, YELLOW;

    public LightState next() {
        return switch (this) {
            case RED    -> GREEN;
            case GREEN  -> YELLOW;
            case YELLOW -> RED;
        };
    }
}
