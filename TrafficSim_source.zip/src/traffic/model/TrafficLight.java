package traffic.model;

public class TrafficLight {
    private LightState state;
    private int greenTimeRemaining; // in ticks
    private final int laneIndex;

    public TrafficLight(int laneIndex) {
        this.laneIndex         = laneIndex;
        this.state             = LightState.RED;
        this.greenTimeRemaining = 0;
    }

    public void setState(LightState s, int greenTicks) {
        this.state              = s;
        this.greenTimeRemaining = (s == LightState.GREEN) ? greenTicks : 0;
    }

    public void setState(LightState s) {
        setState(s, 0);
    }

    /** @return true if green time expired */
    public boolean tick() {
        if (state == LightState.GREEN && greenTimeRemaining > 0) {
            greenTimeRemaining--;
            return greenTimeRemaining == 0;
        }
        return false;
    }

    public LightState getState()          { return state; }
    public int getLaneIndex()             { return laneIndex; }
    public int getGreenTimeRemaining()    { return greenTimeRemaining; }
}
